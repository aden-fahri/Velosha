Sumber mockup Velosha (12 board).
- velosha.css  : token + komponen (sumber kebenaran visual)
- *.dc.html    : tiap halaman; markup HTML/SVG inline biasa, bisa dibaca langsung
  (tag <x-dc>, support.js dan "/_blob/..." hanya runtime kanvas Claude Design; abaikan).
- Gambar pesepeda = rider_final_2048.webp (dikirim terpisah).
- Font: Bricolage Grotesque, Inter, JetBrains Mono (Google Fonts di mockup; di produksi self-host).
