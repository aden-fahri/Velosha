# Mockup Helpdesk Velosha (sumber)

Peta board -> peran:
- HelpdeskBuat.dc.html       Pelapor (peserta): Buat tiket, di dalam portal rider
- HelpdeskTiketSaya.dc.html  Pelapor: Tiket saya + percakapan + rating
- HelpdeskAntrian.dc.html    Operator: Antrian tiket
- HelpdeskDetail.dc.html     Operator: Detail tiket (balas, saran balasan, status/prioritas, SLA)
- HelpdeskAnalitik.dc.html   Admin: Dashboard performa
- HelpdeskSLA.dc.html        Admin: Kebijakan SLA + template balasan otomatis
- Help.dc.html               Halaman Bantuan publik: lihat kartu "Belum ketemu jawabannya? Buat tiket bantuan"
- Portal.dc.html             Portal rider (acuan sidebar; helpdesk menambah item "Tiket bantuan")
- velosha.css, helpdesk.css  Token dan komponen (sumber visual)

Catatan: file .dc.html butuh support.js milik artifact (tidak disertakan); gunakan sebagai referensi markup dan CSS, bukan untuk dijalankan langsung.
Angka dan nama di mockup adalah DATA CONTOH, jangan dipakai sebagai data nyata.
Acuan lengkap: PRD/helpdesk.md dan PRD/desain-revisi.md.
